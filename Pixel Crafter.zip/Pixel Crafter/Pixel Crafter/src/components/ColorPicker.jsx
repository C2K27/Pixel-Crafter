import React, { useState } from "react";

const ColorPicker = ({ currentColor, setCurrentColor, maxColors = 5 }) => {
  const [recentColors, setRecentColors] = useState([]);

  const randomizeColor = () => {
    const randomColor = "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0");
    selectColor(randomColor);
  };

  const selectColor = (color) => {
    setCurrentColor(color);
    
    const filtered = recentColors.filter(c => c !== color);
    const updated = [color, ...filtered];
    setRecentColors(updated.slice(0, maxColors));
  };

  return (
    <div className="color-picker">
      <input
        type="color"
        value={currentColor}
        onChange={(e) => selectColor(e.target.value)}
      />
      <button onClick={randomizeColor}>Randomize</button>

      {recentColors.length > 0 && (
        <div className="recent-colors" style={{ marginTop: "10px" }}>
          <div style={{ fontSize: "12px", marginBottom: "4px", color: "#888" }}>Recent</div>
          <div style={{ display: "flex", gap: "4px", flexWrap: "wrap" }}>
            {recentColors.map((color, i) => (
              <div
                key={i}
                onClick={() => setCurrentColor(color)}
                style={{
                  backgroundColor: color,
                  width: "24px",
                  height: "24px",
                  border: currentColor === color ? "2px solid #555" : "1px solid #ccc",
                  borderRadius: "4px",
                  cursor: "pointer"
                }}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ColorPicker;