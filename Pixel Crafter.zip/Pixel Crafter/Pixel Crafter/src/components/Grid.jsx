import React, { useEffect, useImperativeHandle, useMemo, useRef, useState, forwardRef } from "react";

const Grid = forwardRef(function Grid({
  currentColor,
  gridSize,
  pixelSize = 20,
  showGrid,
  roundedRadius = 0,
  gridOpacity = 0.06,
  currentTool = "pencil",
  onPickColor,
  zoomLevel = 1,
  panOffset = { x: 0, y: 0 },
  onStrokeEnd,
}, ref) {
  const [pixels, setPixels] = useState(() =>
    Array.from({ length: gridSize }, () =>
      Array.from({ length: gridSize }, () => "transparent")
    )
  );
  const [mirrorX, setMirrorX] = useState(false);
  const [mirrorY, setMirrorY] = useState(false);

  const isDrawingRef = useRef(false);
  const lastPointerRef = useRef({ x: 0, y: 0 });
  const containerRef = useRef(null);
  const didDrawRef = useRef(false);

  useEffect(() => {
    setPixels(Array.from({ length: gridSize }, () =>
      Array.from({ length: gridSize }, () => "transparent")
    ));
  }, [gridSize]);

  useImperativeHandle(ref, () => ({
    getPixels: () => pixels.map(row => [...row]),
    setPixels: (newPixels) => setPixels(newPixels.map(row => [...row])),
    clear: () => setPixels(prev => prev.map(row => row.map(() => "transparent"))),
  }), [pixels]);

  const handlePaint = (x, y, color = currentColor) => {
    setPixels(prev => {
      const next = prev.map(row => [...row]);
      const applyPixel = (px, py) => {
        if (px < 0 || py < 0 || px >= gridSize || py >= gridSize) return;
        next[py][px] = color;
      };

      // mirror
      const positions = [{ x, y }];
      if (mirrorX) positions.push({ x: gridSize - 1 - x, y });
      if (mirrorY) positions.push({ x, y: gridSize - 1 - y });
      if (mirrorX && mirrorY) positions.push({ x: gridSize - 1 - x, y: gridSize - 1 - y });

      positions.forEach(pos => applyPixel(pos.x, pos.y));
      return next;
    });
  };

  const handleFill = (x, y, color = currentColor) => {
    const targetColor = pixels[y][x];
    if (targetColor === color) return;

    const next = pixels.map(row => [...row]);
    const stack = [{ x, y }];
    while (stack.length) {
      const { x: sx, y: sy } = stack.pop();
      if (sx < 0 || sy < 0 || sx >= gridSize || sy >= gridSize) continue;
      if (next[sy][sx] !== targetColor) continue;
      next[sy][sx] = color;
      stack.push({ x: sx + 1, y: sy });
      stack.push({ x: sx - 1, y: sy });
      stack.push({ x: sx, y: sy + 1 });
      stack.push({ x: sx, y: sy - 1 });

      // mirror fill
      if (mirrorX) {
        const mx = gridSize - 1 - sx;
        if (next[sy][mx] === targetColor) stack.push({ x: mx, y: sy });
      }
      if (mirrorY) {
        const my = gridSize - 1 - sy;
        if (next[my][sx] === targetColor) stack.push({ x: sx, y: my });
      }
      if (mirrorX && mirrorY) {
        const mx = gridSize - 1 - sx;
        const my = gridSize - 1 - sy;
        if (next[my][mx] === targetColor) stack.push({ x: mx, y: my });
      }
    }
    setPixels(next);
  };

  const pixelStyle = useMemo(() => ({ width: `${pixelSize}px`, height: `${pixelSize}px` }), [pixelSize]);

  const toGridCoords = (clientX, clientY) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return { x: 0, y: 0 };
    const x = Math.floor((clientX - rect.left - panOffset.x) / (pixelSize * zoomLevel));
    const y = Math.floor((clientY - rect.top - panOffset.y) / (pixelSize * zoomLevel));
    return { x, y };
  };

  const handlePointer = (clientX, clientY) => {
    const { x, y } = toGridCoords(clientX, clientY);
    if (x < 0 || y < 0 || x >= gridSize || y >= gridSize) return;

    if (currentTool === "pencil") handlePaint(x, y);
    if (currentTool === "eraser") handlePaint(x, y, "transparent");
    if (currentTool === "fill") handleFill(x, y);
    if (currentTool === "eyedropper" && onPickColor) onPickColor(pixels[y][x] || "#000000");
  };

  const handleMouseDown = (e) => {
    if (e.button === 0) {
      isDrawingRef.current = true;
      didDrawRef.current = currentTool === "pencil" || currentTool === "eraser" || currentTool === "fill";
      handlePointer(e.clientX, e.clientY);
    }
  };

  const handleMouseMove = (e) => {
    if (isDrawingRef.current) {
      handlePointer(e.clientX, e.clientY);
    }
  };

  return (
    <div
      className={`grid-container ${showGrid ? "show-grid" : ""}`}
      onMouseDown={handleMouseDown}
      onMouseUp={() => { if (isDrawingRef.current && didDrawRef.current && onStrokeEnd) onStrokeEnd(); isDrawingRef.current = false; didDrawRef.current = false; }}
      onMouseLeave={() => { if (isDrawingRef.current && didDrawRef.current && onStrokeEnd) onStrokeEnd(); isDrawingRef.current = false; didDrawRef.current = false; }}
      onMouseMove={handleMouseMove}
      onTouchStart={(e) => { handlePointer(e.touches[0].clientX, e.touches[0].clientY); }}
      onTouchMove={(e) => { handlePointer(e.touches[0].clientX, e.touches[0].clientY); e.preventDefault(); }}
      style={{ cursor: currentTool === "zoom" ? "zoom-in" : "crosshair", userSelect: "none" }}
    >
      <div ref={containerRef} style={{ transform: `translate(${panOffset.x}px, ${panOffset.y}px) scale(${zoomLevel})`, transformOrigin: '0 0', willChange: 'transform' }}>
        <div
          className="grid"
          style={{
            gridTemplateColumns: `repeat(${gridSize}, ${pixelSize}px)`,
            gridTemplateRows: `repeat(${gridSize}, ${pixelSize}px)`,
          }}
        >
          {pixels.map((row, y) =>
            row.map((color, x) => (
              <div
                key={`${x}-${y}`}
                className="pixel"
                style={{
                  ...pixelStyle,
                  backgroundColor: color || "transparent",
                  borderRadius: `${roundedRadius}%`,
                  borderColor: showGrid ? `rgba(0,0,0,${gridOpacity})` : "transparent"
                }}
              />
            ))
          )}
        </div>
      </div>
    </div>
  );
});

export default Grid;
