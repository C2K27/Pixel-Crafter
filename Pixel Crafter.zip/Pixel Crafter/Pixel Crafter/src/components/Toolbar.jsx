import React from "react";
import "../styles/index.css";

const Toolbar = ({
  clearGrid,
  undo,
  redo,
  toggleGrid,
  showGrid,
  exportPNG,
  exportSVG,
  exportJSON,
  importJSON,
  gridSize,
  setGridSize,
  handleImageUpload,
  onZoomIn,
  onZoomOut,
  roundedRadius,
  setRoundedRadius,
  gridOpacity,
  setGridOpacity,
  zoomMode,
  setZoomMode
}) => {
  const buttonStyle = {
    padding: "5px 10px",
    border: "none",
    borderRadius: "8px",
    backgroundColor: "#f2f2f7",
    cursor: "pointer",
    fontSize: "14px",
    transition: "background-color 0.2s"
  };

  const buttonHover = (e) => (e.target.style.backgroundColor = "#e0e0e5");
  const buttonLeave = (e) => (e.target.style.backgroundColor = "#f2f2f7");

  return (
    <div className="toolbar">

      <div className="tool-group">
        <button style={buttonStyle} onClick={clearGrid} onMouseEnter={buttonHover} onMouseLeave={buttonLeave}>Clear</button>
        <button style={buttonStyle} onClick={undo} onMouseEnter={buttonHover} onMouseLeave={buttonLeave}>Undo</button>
        <button style={buttonStyle} onClick={redo} onMouseEnter={buttonHover} onMouseLeave={buttonLeave}>Redo</button>
        <button style={buttonStyle} onClick={toggleGrid} onMouseEnter={buttonHover} onMouseLeave={buttonLeave}>{showGrid ? "Hide Grid" : "Show Grid"}</button>
        <button style={{...buttonStyle, backgroundColor: zoomMode ? '#00d1ff' : buttonStyle.backgroundColor, color: zoomMode ? '#061215' : undefined}} onClick={() => setZoomMode(!zoomMode)} onMouseEnter={buttonHover} onMouseLeave={(e)=>{ if(!zoomMode) buttonLeave(e)}}>{zoomMode ? "Zoom Mode" : "Draw Mode"}</button>
      </div>

      <div className="export-group">
        <button style={buttonStyle} onClick={exportPNG} onMouseEnter={buttonHover} onMouseLeave={buttonLeave}>Export PNG</button>
        <button style={buttonStyle} onClick={exportSVG} onMouseEnter={buttonHover} onMouseLeave={buttonLeave}>Export SVG</button>
        <button style={buttonStyle} onClick={exportJSON} onMouseEnter={buttonHover} onMouseLeave={buttonLeave}>Export JSON</button>
      </div>

      <div className="file-group">
        <label style={{ ...buttonStyle, display: "inline-block" }}>
          Import JSON
          <input type="file" accept="application/json" onChange={importJSON} style={{ display: "none" }} />
        </label>
        <label style={{ ...buttonStyle, display: "inline-block" }}>
          Upload Image
          <input type="file" accept="image/*" onChange={handleImageUpload} style={{ display: "none" }} />
        </label>
      </div>

      <div className="grid-size">
        <select
          value={gridSize}
          onChange={(e) => setGridSize(parseInt(e.target.value))}
          style={{ padding: "4px 8px", borderRadius: "6px", border: "1px solid #ccc", backgroundColor: "#f2f2f7", cursor: "pointer" }}
        >
          <option value={8}>8x8</option>
          <option value={16}>16x16</option>
          <option value={32}>32x32</option>
        </select>
      </div>

      <div className="toolbar-section">
        <label>Zoom</label>
        <div style={{ display: 'flex', gap: 8 }}>
          <button style={buttonStyle} onClick={onZoomOut} onMouseEnter={buttonHover} onMouseLeave={buttonLeave}>-</button>
          <button style={buttonStyle} onClick={onZoomIn} onMouseEnter={buttonHover} onMouseLeave={buttonLeave}>+</button>
        </div>
      </div>

      <div className="toolbar-section">
        <label>Pixel Radius</label>
        <input
          type="range"
          min={0}
          max={50}
          value={roundedRadius}
          onChange={(e) => setRoundedRadius(parseInt(e.target.value))}
          style={{ width: '100%' }}
        />
      </div>

      <div className="toolbar-section">
        <label>Grid Opacity</label>
        <input
          type="range"
          min={0}
          max={100}
          value={Math.round(gridOpacity * 100)}
          onChange={(e) => setGridOpacity(parseInt(e.target.value) / 100)}
          style={{ width: '100%' }}
        />
      </div>

    </div>
  );
};

export default Toolbar;
