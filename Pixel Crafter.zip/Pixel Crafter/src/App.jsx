import React, { useEffect, useState, useRef } from "react";
import ColorPicker from "./components/ColorPicker";
import Grid from "./components/Grid";

function App() {
  const [currentColor, setCurrentColor] = useState("#000000");
  const [showGrid, setShowGrid] = useState(true);
  const [gridSize, setGridSize] = useState(16);
  const [history, setHistory] = useState([]);
  const [redoStack, setRedoStack] = useState([]);
  const [roundedRadius, setRoundedRadius] = useState(0);
  const [gridOpacity, setGridOpacity] = useState(0.06);
  const [pixelSize, setPixelSize] = useState(20);
  const [currentTool, setCurrentTool] = useState("pencil");
  const [zoomLevel, setZoomLevel] = useState(1);
  const [panOffset, setPanOffset] = useState({ x: 0, y: 0 });
  const isPanning = useRef(false);
  const panStart = useRef({ x: 0, y: 0 });
  const isMiddlePanning = useRef(false);
  const pinchRef = useRef({ isPinching: false, startDist: 0, startZoom: 1, startPan: { x: 0, y: 0 }, startCenter: { x: 0, y: 0 } });

  const gridRef = useRef();

  const saveHistory = () => {
    const pixels = gridRef.current.getPixels();
    setHistory((prev) => [...prev, pixels]);
    setRedoStack([]);
  };

  const clearGrid = () => {
    saveHistory();
    gridRef.current?.clear();
  };

  const undo = () => {
    if (!history.length) return;
    const last = history[history.length - 1];
    setHistory((prev) => prev.slice(0, prev.length - 1));
    setRedoStack((prev) => [...prev, gridRef.current.getPixels()]);
    gridRef.current?.setPixels(last);
  };

  const redo = () => {
    if (!redoStack.length) return;
    const last = redoStack[redoStack.length - 1];
    setRedoStack((prev) => prev.slice(0, prev.length - 1));
    setHistory((prev) => [...prev, gridRef.current.getPixels()]);
    gridRef.current?.setPixels(last);
  };

  const toggleGrid = () => setShowGrid(!showGrid);

  const handleZoom = (delta, center) => {
    const newZoom = Math.min(5, Math.max(0.25, zoomLevel + delta * 0.1));
    if (!center) {
      setZoomLevel(newZoom);
      return;
    }
    const rect = center.rect;
    const offsetX = center.x - rect.left - panOffset.x;
    const offsetY = center.y - rect.top - panOffset.y;
    const ratio = newZoom / zoomLevel;
    setPanOffset({
      x: center.x - rect.left - offsetX * ratio,
      y: center.y - rect.top - offsetY * ratio,
    });
    setZoomLevel(newZoom);
  };

  const onMouseDown = (e) => {
    if (e.button === 1) {
      isPanning.current = true;
      isMiddlePanning.current = true;
      panStart.current = { x: e.clientX - panOffset.x, y: e.clientY - panOffset.y };
      e.preventDefault();
    }
  };

  const onMouseMove = (e) => {
    if (isPanning.current) {
      setPanOffset({ x: e.clientX - panStart.current.x, y: e.clientY - panStart.current.y });
    }
  };

  const onMouseUp = () => {
    isPanning.current = false;
    isMiddlePanning.current = false;
  };

  useEffect(() => {
    const handleKey = (e) => {
      if (e.key.toLowerCase() === "z") {
        setCurrentTool((t) => (t === "zoom" ? "pencil" : "zoom"));
      }
      if (e.key.toLowerCase() === "b") setCurrentTool("pencil");
      if (e.key.toLowerCase() === "e") setCurrentTool("eraser");
      if (e.key.toLowerCase() === "i") setCurrentTool("eyedropper");
      if (e.key.toLowerCase() === "f") setCurrentTool("fill");
      if (e.key === "+" || (e.key === "=" && e.shiftKey)) handleZoom(1);
      if (e.key === "-" || e.key === "_") handleZoom(-1);
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, []);

  const exportPNG = () => {
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    const size = 20;
    canvas.width = gridSize * size;
    canvas.height = gridSize * size;
    const pixels = gridRef.current.getPixels();
    for (let y = 0; y < gridSize; y++) {
      for (let x = 0; x < gridSize; x++) {
        ctx.fillStyle = pixels[y][x];
        ctx.fillRect(x * size, y * size, size, size);
      }
    }
    const link = document.createElement("a");
    link.download = "pixel-art.png";
    link.href = canvas.toDataURL();
    link.click();
  };

  const exportSVG = () => {
    const pixels = gridRef.current.getPixels();
    const size = 20;
    const width = gridSize * size;
    const height = gridSize * size;
    let rects = "";
    for (let y = 0; y < gridSize; y++) {
      for (let x = 0; x < gridSize; x++) {
        const color = pixels[y][x];
        if (color && color !== "transparent") {
          rects += `<rect x="${x * size}" y="${y * size}" width="${size}" height="${size}" fill="${color}"/>`;
        }
      }
    }
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}">${rects}</svg>`;
    const blob = new Blob([svg], { type: "image/svg+xml" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "pixel-art.svg";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const exportJSON = () => {
    const data = {
      gridSize,
      pixels: gridRef.current.getPixels(),
    };
    const blob = new Blob([JSON.stringify(data)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "pixel-art.json";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const importJSON = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        if (Array.isArray(data?.pixels)) {
          saveHistory();
          if (typeof data.gridSize === "number" && data.gridSize !== gridSize) {
            setGridSize(data.gridSize);
            setTimeout(() => gridRef.current?.setPixels(data.pixels), 0);
          } else {
            gridRef.current?.setPixels(data.pixels);
          }
        }
      } catch {}
    };
    reader.readAsText(file);
  };

  const importImage = (e) => {
    const file = e.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    const img = new Image();

    reader.onload = (event) => {
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const ctx = canvas.getContext("2d");
        canvas.width = gridSize;
        canvas.height = gridSize;
        ctx.drawImage(img, 0, 0, gridSize, gridSize);

        const imageData = ctx.getImageData(0, 0, gridSize, gridSize);
        const pixels = [];
        for (let y = 0; y < gridSize; y++) {
          const row = [];
          for (let x = 0; x < gridSize; x++) {
            const i = (y * gridSize + x) * 4;
            const r = imageData.data[i];
            const g = imageData.data[i + 1];
            const b = imageData.data[i + 2];
            row.push(`rgb(${r},${g},${b})`);
          }
          pixels.push(row);
        }
        saveHistory();
        gridRef.current?.setPixels(pixels);
      };
      img.src = event.target.result;
    };

    reader.readAsDataURL(file);
  };

  const importAny = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if ((file.type || '').includes('json')) {
      importJSON(e);
    } else {
      importImage(e);
    }
  };

  return (
    <div
      className="editor-root"
      onMouseMove={onMouseMove}
      onMouseUp={onMouseUp}
      onMouseLeave={onMouseUp}
    >
      <div className="window">
        <div className="topbar">
          <div className="tools">
            <button className={currentTool === "pencil" ? "active" : ""} onClick={() => setCurrentTool("pencil")}>Pencil</button>
            <button className={currentTool === "eraser" ? "active" : ""} onClick={() => setCurrentTool("eraser")}>Eraser</button>
            <button className={currentTool === "eyedropper" ? "active" : ""} onClick={() => setCurrentTool("eyedropper")}>Eyedropper</button>
            <button className={currentTool === "fill" ? "active" : ""} onClick={() => setCurrentTool("fill")}>Fill</button>
            <button onClick={clearGrid}>Trash</button>
          </div>
          <div className="right">
            <input type="file" accept="application/json,image/*" onChange={importAny} />
          </div>
        </div>

        <div className="main">
          <div
            className="canvas-wrap"
            onWheel={(e) => {
              if (currentTool === "zoom") {
                handleZoom(e.deltaY > 0 ? -1 : 1, { x: e.clientX, y: e.clientY, rect: e.currentTarget.getBoundingClientRect() });
                e.preventDefault();
              }
            }}
            onMouseDown={onMouseDown}
            style={{ overflow: "hidden", cursor: isMiddlePanning.current ? "grabbing" : (currentTool === "zoom" ? "zoom-in" : "crosshair") }}
            onTouchStart={(e) => {
              if (e.touches.length === 2) {
                const [t1, t2] = [e.touches[0], e.touches[1]];
                const dx = t2.clientX - t1.clientX;
                const dy = t2.clientY - t1.clientY;
                const dist = Math.hypot(dx, dy);
                const rect = e.currentTarget.getBoundingClientRect();
                const center = { x: (t1.clientX + t2.clientX) / 2, y: (t1.clientY + t2.clientY) / 2 };
                pinchRef.current = {
                  isPinching: true,
                  startDist: dist,
                  startZoom: zoomLevel,
                  startPan: { ...panOffset },
                  startCenter: { x: center.x - rect.left, y: center.y - rect.top }
                };
                e.preventDefault();
              }
            }}
            onTouchMove={(e) => {
              if (pinchRef.current.isPinching && e.touches.length === 2) {
                const [t1, t2] = [e.touches[0], e.touches[1]];
                const dx = t2.clientX - t1.clientX;
                const dy = t2.clientY - t1.clientY;
                const dist = Math.hypot(dx, dy);
                const rect = e.currentTarget.getBoundingClientRect();
                const center = { x: (t1.clientX + t2.clientX) / 2 - rect.left, y: (t1.clientY + t2.clientY) / 2 - rect.top };
                const ratio = dist / pinchRef.current.startDist;
                const newZoom = Math.min(5, Math.max(0.25, pinchRef.current.startZoom * ratio));
                const zoomRatio = newZoom / pinchRef.current.startZoom;
                const offsetX = pinchRef.current.startCenter.x - pinchRef.current.startPan.x;
                const offsetY = pinchRef.current.startCenter.y - pinchRef.current.startPan.y;
                setPanOffset({
                  x: center.x - offsetX * zoomRatio,
                  y: center.y - offsetY * zoomRatio,
                });
                setZoomLevel(newZoom);
                e.preventDefault();
              }
            }}
            onTouchEnd={(e) => {
              if (e.touches.length < 2) {
                pinchRef.current.isPinching = false;
              }
            }}
          >
            <div
              style={{
                transform: `translate(${panOffset.x}px, ${panOffset.y}px) scale(${zoomLevel})`,
                transformOrigin: "top left"
              }}
            >
              <Grid
                ref={gridRef}
                currentColor={currentColor}
                gridSize={gridSize}
                pixelSize={pixelSize}
                showGrid={showGrid}
                roundedRadius={roundedRadius}
                gridOpacity={gridOpacity}
                currentTool={currentTool}
                onPickColor={setCurrentColor}
                zoomLevel={zoomLevel}
                panOffset={panOffset}
                onStrokeEnd={saveHistory}
              />
            </div>
          </div>

          <aside className="sidebar">
            <div className="sidebar-section">
              <span>Pixel size</span>
              <div className="row-controls">
                <button onClick={() => setPixelSize(Math.max(4, pixelSize - 2))}>-</button>
                <span>{pixelSize}px</span>
                <button onClick={() => setPixelSize(Math.min(40, pixelSize + 2))}>+</button>
              </div>
            </div>

            <div className="sidebar-section">
              <span>Pixel radius</span>
              <span>{roundedRadius}px</span>
              <input type="range" min={0} max={50} value={roundedRadius} onChange={(e) => setRoundedRadius(parseInt(e.target.value))} />
            </div>

            <div className="sidebar-section">
              <span>Grid</span>
              <button onClick={toggleGrid}>{showGrid ? "👁️" : "🚫"}</button>
              <input type="range" min={0} max={100} value={Math.round(gridOpacity*100)} onChange={(e) => setGridOpacity(parseInt(e.target.value)/100)} />
            </div>

            <div className="sidebar-section">
              <ColorPicker currentColor={currentColor} setCurrentColor={setCurrentColor} />
            </div>

            <div className="sidebar-section zoom">
              <span>Zoom</span>
              <div className="row-controls">
                <button onClick={() => handleZoom(-1)}>−</button>
                <button onClick={() => handleZoom(1)}>+</button>
              </div>
            </div>
          </aside>
        </div>

        <div className="bottombar">
          <button onClick={undo}>Undo</button>
          <button onClick={redo}>Redo</button>
          <button onClick={exportPNG}>Export PNG</button>
          <button onClick={exportSVG}>Export SVG</button>
          <button onClick={exportJSON}>Export JSON</button>
          <button onClick={clearGrid}>Clear</button>
        </div>
      </div>
    </div>
  );
}

export default App;
