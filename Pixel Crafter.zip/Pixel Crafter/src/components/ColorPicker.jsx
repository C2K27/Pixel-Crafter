import React, { useState } from "react";
import "../styles/index.css";

const ColorPicker = ({ currentColor, setCurrentColor }) => {
  const [palette, setPalette] = useState([
    "#1c1c1e", // dark gray
    "#f2f2f7", // light gray
    "#ff3b30", // subtle red
    "#ff9500", // muted orange
    "#ffcc00", // warm yellow
    "#30d158", // soft green
    "#0a84ff", // Apple blue
    "#5e5ce6"  // pastel purple
  ]);

  const randomizePalette = () => {
    const randomColor = () =>
      "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0");
    setPalette(palette.map(() => randomColor()));
  };

  const handleColorChange = (index, value) => {
    const newPalette = [...palette];
    newPalette[index] = value;
    setPalette(newPalette);
  };

  return (
    <div className="color-picker">
      <input
        type="color"
        value={currentColor}
        onChange={(e) => setCurrentColor(e.target.value)}
      />
      <button onClick={randomizePalette}>Randomize</button>

      <div className="palette">
        {palette.map((color, i) => (
          <div key={i} className="palette-item">
            <div
              onClick={() => setCurrentColor(color)}
              style={{
                backgroundColor: color,
                width: "24px",
                height: "24px",
                border: currentColor === color ? "2px solid #555" : "1px solid #ccc",
                borderRadius: "4px",
                cursor: "pointer"
              }}
            />
            <input
              type="color"
              value={color}
              onChange={(e) => handleColorChange(i, e.target.value)}
              style={{ width: "24px", height: "24px", border: "none" }}
            />
          </div>
        ))}
      </div>
    </div>
  );
};

export default ColorPicker;
